package lab8_1;

public class Truck extends Car{

    private double M_weight; //max load
    private double weight; //load(ton)

    public Truck(double gas, double efficiency, double weight, double M_weight){
        super(gas,efficiency);
        if(weight >= M_weight){
            this.weight = M_weight;
        }
        else{
            this.weight = weight;
        }
    }

    @Override
    public void drive(double distance){
        if(weight < 1){
            super.drive(distance);
        }
        else if(weight <= 10){
            if((distance/super.getEfficiency())*1.1 > super.getGas()) System.out.println("You cannot drive too far, please add gas");
            else super.setGas(super.getGas() - ((distance/super.getEfficiency())*1.1));
        }
        else if(weight <= 20){
            if((distance/super.getEfficiency())*1.2 > super.getGas()) System.out.println("You cannot drive too far, please add gas");
            else super.setGas(super.getGas() - ((distance/super.getEfficiency())*1.2));
        }
        else{
            if((distance/super.getEfficiency())*1.3 > super.getGas()) System.out.println("You cannot drive too far, please add gas");
            else super.setGas(super.getGas() - ((distance/super.getEfficiency())*1.3));
        }
    }
}