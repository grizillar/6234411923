
package lab3_2;

public class LetterPrinter {
    
    public static void main(String[] args){
        Letter myLetter = new Letter("Clarissa","Jade");
        myLetter.addLine("We must find Simon quickly.");
        myLetter.addLine("He might be in danger.");
        System.out.println(myLetter.getText());
    }
}
