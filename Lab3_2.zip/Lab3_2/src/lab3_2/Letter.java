package lab3_2;

public class Letter {
    
    private String text = "";
    private final String from;
    private final String to;
    
    public Letter(String from, String to){
        this.from = from;
        this.to = to;
    }
    
    public void addLine(String line){
        text = text + line + "\n";
    }
    
    public String getText(){
        return "Dear "+ to + ":" + "\n\n" + text + "\n" + "Sincerely," + "\n\n" + from;
    }
    
}
