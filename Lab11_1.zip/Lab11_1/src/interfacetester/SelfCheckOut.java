package interfacetester;

import java.util.ArrayList;

public class SelfCheckOut implements SimpleQueue {
    
    private ArrayList<Product> queue = new ArrayList<>();
    private double amount;

    public double getAmount(){return amount;}

    @Override
    public void enqueue(Object o){
        try{
            Product product = (Product) o;
            queue.add(product);
            System.out.printf("%s is added in queue%n",product.getName());
        }
        catch(Exception e){
            return;
        }
    }

    @Override
    public void dequeue(){
        try{
            amount += queue.get(0).getPrice();
            queue.remove(queue.get(0));
        }
        catch(Exception e){
            return;
        }
    }
}