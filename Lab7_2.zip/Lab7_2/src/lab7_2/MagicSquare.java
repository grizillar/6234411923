
package lab7_2;

//Main included below.
public class MagicSquare {

    public int[][] table;

    public MagicSquare(int n){
        table = new int[n][n];
        //start with 1 in middle-bottom
        //table[row][column]
        int row = n-1;
        int column = n/2;
        int max = n-1;
        for(int i = 1;i <= (n*n);i++){
            //System.out.printf("%d,%d assign %d%n",row,column,i);
            table[row][column] = i;
            if(row == max && column == max){
                row--;
            }
            else if(row == max){
                row = 0;
                column++;
            }
            else if(column == max){
                column = 0;
                row ++;
            }
            else if(table[row+1][column+1] != 0){
                row--;
            }
            else if(table[row+1][column+1] == 0){
                row++;
                column++;
            }
        }
    }

    @Override
    public String toString(){ 
        String display = "";
        for(int i = 0;i < table.length;i++){
            for(int j = 0;j < table[0].length;j++){
                display = display + table[i][j] + " ";
            }
            display = display + "\n";
        }
        return display;
        
    }



    public static void main(String[] args) {
        MagicSquare tab = new MagicSquare(5);
        System.out.println(tab.toString());
    }
    
}
