
package lab5_2;

import java.util.Scanner;

public class LineTester {
    
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        Line l1 = new Line(0.44,3.4); Line l2 = new Line(0.44,5); 
        System.out.println("Are the two lines equals?: "+l1.equals(l2));
        System.out.println("Are the two lines parallel?: "+l1.isParallel(l2));
        System.out.println("Do the two lines intersect?: "+l1.isIntersect(l2));
        //no return if null
        if (l1.getIntersectionPoint(l2) == null){}
        //or else?
        else{
        System.out.println("Point of intersection: "+l1.getIntersectionPoint(l2));
        }
    }
    
}
