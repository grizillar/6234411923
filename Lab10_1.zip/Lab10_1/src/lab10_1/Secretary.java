package lab10_1;

public class Secretary extends Employee implements Evaluation{
    private int typingSpeed;
    private int[] score;

    public Secretary(String name, int salary, int[] score, int typingSpeed){
        super(name, salary);
        this.typingSpeed = typingSpeed;
        this.score = score;
    }

    @Override
    public double evaluate(){
        double root = 0;
        for(int score : this.score){
            root += score;
        }
        return root;
    }

    @Override
    public char grade(double root){
        if(root >= 90) {
            setSalary(18000);
            return 'P';
        }
        else return 'F';
    }

}