package lab10_1;

public class Subject implements Evaluation{
    private String subjName;
    private int[] score;

    public Subject(String subjName, int[] score){
        this.subjName = subjName;
        this.score = score;
    }

    @Override
    public double evaluate(){
        double root = 0;
        for(int s : score){
            root += s;
        }
        return root/score.length;
    }

    @Override
    public char grade(double root){
        if(root >= 70) return 'P';
        else return 'F';
    }

    @Override
    public String toString(){
        return subjName;
    }
}