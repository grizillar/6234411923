package lab8_2;

import java.util.ArrayList;

public class ChoiceQuestion extends Question{

    private ArrayList<String> choices = new ArrayList<String>();

    public ChoiceQuestion(String text){
        super(text);
    }

    public void addChoice(String choice, boolean correct){
        choices.add(choice);
        if(correct) super.setAnswer(choice);
    }

    @Override
    public void display(){
        System.out.println(super.getText());
        for(int i = 0;i < choices.size();i++){
            System.out.printf("%d: %s%n",(i+1),choices.get(i));
        }
    }

    @Override
    public boolean checkAnswer(String response){
        int a = Integer.parseInt(response);
        if(choices.get(a-1).equals(super.getAnswer())) return true;
        else return false;
    }
    
}