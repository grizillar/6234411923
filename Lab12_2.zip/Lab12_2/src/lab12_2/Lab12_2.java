package lab12_2;

import java.io.*;
import java.util.*;

public class Lab12_2 {

    public static void main(String[] args) {

        ArrayList<String> wordList = new ArrayList<String>();
        ArrayList<String> sentence = new ArrayList<String>();
        ArrayList<String> wordsNotContained = new ArrayList<String>();
        Scanner in = new Scanner(System.in);
        
        //Sentence arrayList creates from user-input.
        System.out.print("Enter a sentence:");
        for(String w : in.nextLine().split("\\s+")){
            sentence.add(w);
        }
        
        //Try open wordlist.txt and add to new arrayList
        try{
            File file = new File("src\\lab12_2\\wordlist.txt");
            Scanner read = new Scanner(file);
            while(read.hasNextLine()){
                wordList.add(read.nextLine());
            }
        }
        catch(Exception e){System.out.println(e);}

        //Check if word contained in wordlist arrayList
        for(String word : sentence){
            if(!wordList.contains(word)){wordsNotContained.add(word);}
        }

        //Print result
        System.out.println("Words not contained:");
        if(wordsNotContained.isEmpty()){
            System.out.println("N/A");
        }
        else{
            for(String word : wordsNotContained){
                System.out.println(word);
            }
        }
    }
    
}
