
package lab6_2;

import java.util.Random;
import java.util.Scanner;
import java.lang.Math;

public class Game {
    
    private int playerScore;
    private int botScore;
    
    //Input-Control
    public static boolean Check(String str){
        if (str == null) return false;
        try {int i = Integer.parseInt(str);}
        catch (NumberFormatException nfe) {return false;}
        return true;
    }

    //Win-Conditions
    public static char Win(int player, int bot){
        switch (player){
            case 0: //ROCK
                switch(bot){
                    case 0: return 'T';
                    case 1: return 'L';
                    case 2: return 'W';
                }
            case 1: //PAPER
                switch(bot){
                    case 0: return 'W';
                    case 1: return 'T';
                    case 2: return 'L';
                }
            case 2: //SCISSORS
                switch(bot){
                    case 0: return 'L';
                    case 1: return 'W';
                    case 2: return 'T';
                }
        }
        return 0;
    }

    //Callouts
    public static String Call(int value){
        switch(value){
            case 0: return "ROCK";
            case 1: return "PAPER";
            case 2: return "SCISSORS";
            default: return "ERROR";
        }
    }
    
    public void Play(){
        
        Scanner input = new Scanner(System.in);
        Random random = new Random();
        
        while(Math.abs(playerScore - botScore) < 2){
            
            char result = 0;
            
            System.out.print("Enter 0 for ROCK, 1 for PAPER, 2 for SCISSORS: ");
            
            String strPlayer = input.nextLine();
            if(Check(strPlayer)){
                int player = Integer.parseInt(strPlayer);
                if(player == 0 || player == 1 || player == 2){
                    System.out.printf("You Enter: %s%n",Call(player));
                    int bot = random.nextInt(3);
                    System.out.printf("Computer: %s%n",Call(bot));

                    result = Win(player , bot);
                    switch (result){
                        case 'W': System.out.println("You win!"); playerScore++; break;
                        case 'L': System.out.println("You lose!"); botScore++; break;
                        case 'T': System.out.println("It's tie."); break;
                    }
                }
            }
        }
        System.out.println("----------------------------------------");
        if(playerScore > botScore) System.out.println("Congrats! You win.");
        else if(botScore > playerScore) System.out.println("Too bad! You lose.");
        System.out.printf("User Score: %d%n",playerScore);
        System.out.printf("Computer Score: %d%n",botScore);
        }
    } 

