
package lab2_2;

public class HollePrintor {

    public static void main(String[] args) {
        String s1 = "Hello World";
        String s2 = s1.replace('o','*').replace('e','o').replace('*','e');
        System.out.println(s2);
    }
    
}
