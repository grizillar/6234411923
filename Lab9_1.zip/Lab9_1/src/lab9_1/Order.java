package lab9_1;

import java.util.ArrayList;

public class Order{
    public static int cntOrder = 0; //Auto-Generated Order number
    //private int id;
    private Customer c;
    private ArrayList<Pizza> p;

    public Order(Customer customer){
        p = new ArrayList<Pizza>();
        c = customer;
        cntOrder++;
    }

    public void addPizza(Pizza pizza){
        p.add(pizza);
    }

    public double calculatePayment(){
        double total = 0;
        for(Pizza pizza : p){
            total += pizza.getPrice();
        }
        if(c instanceof GoldCustomer){
            GoldCustomer gc = (GoldCustomer)c;
            return total - (total * (gc.getDiscount()/100));
        }
        else{
            return total;
        }
        /*
        try{
            GoldCustomer gc = (GoldCustomer)c;
            return total - (total * (gc.getDiscount()/100));
        }
        catch(Exception e){
            return total;
        }
        **/
    }

    public String getOrderDetail(){
        //Order id
        String orderid = String.format("Order id : %d%n", cntOrder);
        //Customer Information
        String customer = c.toString();
        //For each orders
        String orders = "";
        for(Pizza pizza : p){
            orders += pizza.toString();
        }
        //Total
        String totalPiece = String.format("Total Pieces : %d%n", p.size());
        String totalCost = String.format("Total cost : %.1f%n", calculatePayment());
        return orderid + customer + orders + totalPiece + totalCost;
    }
}