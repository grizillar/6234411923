
package lab2_1;

import java.util.Random;
import java.awt.Rectangle;

public class IntersectionPrinter {

    public static void main(String[] args) {
        Random generator = new Random();
        //generator.nextInt(6);
        Rectangle r1 = new Rectangle(generator.nextInt(50)+1,generator.nextInt(50)+1,generator.nextInt(50)+1,generator.nextInt(50)+1);
        Rectangle r2 = new Rectangle(generator.nextInt(50)+1,generator.nextInt(50)+1,generator.nextInt(50)+1,generator.nextInt(50)+1);
        //Rectangle r1 = new Rectangle(22,20,38,11);
        //Rectangle r2 = new Rectangle(8,22,4,38);
        System.out.println(r1);
        System.out.println(r2);
        Rectangle intersection = r1.intersection(r2);
        System.out.println("Is the intersected rectangle empty?:"+intersection.isEmpty());
    }
    
}
