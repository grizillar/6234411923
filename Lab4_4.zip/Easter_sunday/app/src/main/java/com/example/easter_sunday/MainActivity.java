package com.example.easter_sunday;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import android.content.Intent;

public class MainActivity extends AppCompatActivity {

    public static final String EXTRA_NUMBER = "com.example.easter_sunday.EXTRA_NUMBER";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Button button = (Button) findViewById(R.id.button);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity2();
            }
        });
    }
    public void openActivity2(){

        EditText inputNumber = (EditText) findViewById(R.id.numberInput);
        int number = Integer.parseInt(inputNumber.getText().toString());

        Intent intent = new Intent(this, Main2Activity.class);
        intent.putExtra(EXTRA_NUMBER, number);
        startActivity(intent);
    }
}
