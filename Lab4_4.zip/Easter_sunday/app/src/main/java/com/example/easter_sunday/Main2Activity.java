package com.example.easter_sunday;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Intent intent = getIntent();
        int y = intent.getIntExtra(MainActivity.EXTRA_NUMBER,0);

        int a = y % 19;
        int c = y % 100;
        int b = y / 100;
        int e = b % 4;
        int d = b / 4;
        int g = (8 * b + 13)/25;
        int h = (19 * a + b - d - g + 15)%30;
        int j = c / 4;
        int k = c % 4;
        int m = (a + 11 * h)/319;
        int r = ( 2 * e + 2 * j - k - h + m + 32)%7;
        int n = ( h - m + r + 90)/25;
        int p = (h - m + r + n + 19)%32;

        String result = p + " " + getMonth(n);

        TextView textview = (TextView) findViewById(R.id.textView);

        textview.setText(result);

    }

    private static String getMonth(int n){
        switch (n){
            case 1:
                return "January";
            case 2:
                return "February";
            case 3:
                return "March";
            case 4:
                return "April";
            case 5:
                return "May";
            case 6:
                return "June";
            case 7:
                return "July";
            case 8:
                return "August";
            case 9:
                return "September";
            case 10:
                return "October";
            case 11:
                return "November";
            case 12:
                return "December";

        }
        return null;
    }

}
