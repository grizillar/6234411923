package lab9_2;

import java.lang.Math;

public class sine extends Taylor{

    public sine(int k, double x){
        setIter(k);
        setValue(x);
    }

    @Override
    public double getApprox(){
        double a = 0;
        double x = getValue();
        int k = getIter();
        for(int n = 0;n <= k;n++){
            double u = 1;
            for(int i = 0;i < (2*n+1);i++){
                u = u * x;
            }
            int v = -1;
            for(int i = 0;i <= n;i++){
                v = v * -1;
            }
            a += v*u/factorial(2*n+1);
        }
        return a;
    }
    @Override
    public void printValue(){
        System.out.println("Value from Math.sin() is " + Math.sin(getValue()) + ".");
        System.out.println("Approximated value is " + getApprox() + ".");
    }

}