package lab9_2;

import java.lang.Math;

public class expo extends Taylor{

    public expo(int k, double x){
        setIter(k);
        setValue(x);
    }

    @Override
    public double getApprox(){
        double a = 0;
        double x = getValue();
        int k = getIter();
        for(int n = 0;n <= k;n++){
            double u = 1;
            for(int i = 0;i < n;i++){
                u = u * x;
            }
            a += u/factorial(n);
        }
        return a;
    }
    @Override
    public void printValue(){
        System.out.println("Value from Math.exp() is " + Math.exp(getValue()) + ".");
        System.out.println("Approximated value is " + getApprox() + ".");
    }

}