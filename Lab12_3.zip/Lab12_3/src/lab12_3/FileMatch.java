package lab12_3;

import java.util.*;
import java.io.*;

public class FileMatch {
    public static void main(String[] args){
        
        RandomAccessFile r = null;

        ArrayList<TransactionRecord> transactionRecords = new ArrayList<>();
        ArrayList<AccountRecord> accountRecords = new ArrayList<>();

        try{
            Scanner master = new Scanner(new File("src\\lab12_3\\master.txt"));
            while(master.hasNext()){
                accountRecords.add(new AccountRecord(Integer.parseInt(master.next()),master.next()+" "+master.next(),Double.parseDouble(master.next())));
            }
            master.close();
        }
        catch(Exception e){System.out.println(e);}

        try{
            Scanner trans = new Scanner(new File("src\\lab12_3\\trans.txt"));
            while(trans.hasNext()){
                transactionRecords.add(new TransactionRecord(Integer.parseInt(trans.next()),Double.parseDouble(trans.next())));
            }
            trans.close();
        }
        catch(Exception e){System.out.println(e);}

        try{
            r = new RandomAccessFile("src\\lab12_3\\newMaster.dat", "rw");
        }
        catch(Exception e){System.out.println(e);}

        for(AccountRecord a : accountRecords){
            for(TransactionRecord t : transactionRecords){
                a.combine(t);

            }
            String name = a.getName();
            for(int i = a.getName().length();i < 30;i++){
                name = name + " ";
            }
            try{
                r.writeInt(a.getAcctNo());
                r.writeChars(name);
                r.writeDouble(a.getBalance());
                r.writeInt(a.getTransCnt());
                r.writeChars("\n");
            }
            catch(Exception e){System.out.println(e);}
        }
    
        try{r.close();}
        catch(Exception e){System.out.println(e);}

        try{
            r = new RandomAccessFile("src\\lab12_3\\newMaster.dat", "rw");
            /*
            Info about newMaster.dat file
            accNO. | name(30) | balance | transNO. | \n
            4 bytes | 60 bytes | 8 bytes | 4 bytes | 2 bytes , totalSize = 78 bytes
            **/

            //Get number of account from .dat file
            System.out.println("Total Account Record : " + r.length()/78);
            //Get total balance from .dat file
            double total = 0;
            for(int i = 64;i < r.length(); i += 78){
                r.seek(i);
                total += r.readDouble();
            }
            System.out.println("Total balance : " + total);
            //Get no-transaction account from .dat file
            int noTransAccount = 0;
            for(int i = 72;i < r.length(); i += 78){
                r.seek(i);
                if(r.readInt() == 0){
                    noTransAccount++;
                }
            }
            System.out.println("No transaction : " + noTransAccount + " account(s).");
        }
        catch(Exception e){System.out.println(e);}

        
    }
}