package lab12_3;

public class TransactionRecord {
    private int acctNo;
    private double amount;

    public TransactionRecord(int acctNo, double amount){
        this.acctNo = acctNo;
        this.amount = amount;
    }

    public int getAcctNo(){return acctNo;}
    public double getAmount(){return amount;}
}
