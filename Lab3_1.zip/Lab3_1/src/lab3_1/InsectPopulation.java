package lab3_1;

public class InsectPopulation {

    private double population;
    
    public InsectPopulation(double iniPopulation){
        population = iniPopulation;
    }
    
    public void breed(){
        population = 2 * population;
    }
    
    public void spray(){
        population = population - (0.1*population);
    }
    
    public double getNumInsect() {
        return population;
    }
}
