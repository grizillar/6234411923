
package lab3_1;

public class InsectPopulationTester {
    public static void main(String[] args){
        InsectPopulation theInsect = new InsectPopulation(10);
        theInsect.breed();
        theInsect.spray();
        System.out.println("Number of insects:"+theInsect.getNumInsect());
        theInsect.breed();
        theInsect.spray();
        System.out.println("Number of insects:"+theInsect.getNumInsect());
        theInsect.breed();
        theInsect.spray();
        System.out.println("Number of insects:"+theInsect.getNumInsect());
    }
}
