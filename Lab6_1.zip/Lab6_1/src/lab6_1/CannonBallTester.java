
package lab6_1;

public class CannonBallTester {
    public static void main(String[] args){
        CannonBall ball = new CannonBall(100);
        ball.simulatedFlight();
        System.out.printf("Distance from calculus equation: %.3f ",ball.calculusFlight(ball.getSimulatedTime()));
    }
}
