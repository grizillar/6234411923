
package lab6_1;

import java.lang.Math;

public class CannonBall {
    
    private double initV; //Initial Velocity
    private double simS; //Simulator height
    private double simT; //Simulator Time
    public static final double g = 9.81;
    
    public CannonBall(double initV){
        this.initV = initV;
    }
    
    public void simulatedFlight(){
        double v = initV;
        double s = 0;
        double ds = 0;
        double dt = 0.01;
        int t = 0;
        double time = 0;
        double timeCounter = 0;
        while(v>0){
            time = time + dt;
            ds = v*dt;
            s = s + ds;
            v = v-g*dt; //Condition Modifier
            timeCounter++;
            if(timeCounter == 100.0){
                t = t + 1;
                System.out.printf("Distance on %d sec: %.2f%n",t,s);
                timeCounter = 0;
            }
        }
        System.out.printf("Final distance: %.2f Total time: %.2f%n",s,time);
        simS = s;
        simT = time;
    }
    
    public double calculusFlight(double t){
        return -0.5*g*Math.pow(t,2) + initV*t;
    }
    
    public double getSimulatedTime(){
        return Math.sqrt((2*simS)/g);
    }
    
    public double getSimulatedDistance(){
        return simS * 2;
    }
}
