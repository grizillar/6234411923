
package lab4_1;

import java.util.Scanner;

public class SodaTester {
    
    public static void main(String[] args){
    Scanner input = new Scanner(System.in);
    System.out.print("Enter height:");
    Double height = input.nextDouble();
    System.out.print("Enter diameter:");
    Double diameter = input.nextDouble();
    SodaCan self = new SodaCan(height,diameter);
    System.out.println("Volume :" + self.getVolume());
    System.out.println("Surface Area :" + self.getSurfaceArea());
    
    }
}
