package lab4_1;

import java.util.Scanner;
import java.lang.Math.*;

public class SodaCan {
    
    public static final double PI = Math.PI;
    
    private double height;
    private double diameter;
    
    public SodaCan(double height,double diameter){
        this.height = height;
        this.diameter = diameter;
    }
    
    public double getVolume(){
        return PI * Math.pow(diameter/2,2) * height;
    }
    
    public double getSurfaceArea(){
        return PI * diameter * height + 2 * PI * Math.pow(diameter/2,2);
    }
    
    
}
