
package lab4_3;

import java.util.Scanner;

public class TimeIntervalTester {

    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        System.out.print("Enter start time: ");
        String startTime = input.nextLine();
        System.out.print("Enter end time: ");
        String endTime = input.nextLine();
        TimeInterval self = new TimeInterval(startTime, endTime);
        System.out.printf("%d hours %d minutes",self.getHours(),self.getMinutes());

    }
    
}
