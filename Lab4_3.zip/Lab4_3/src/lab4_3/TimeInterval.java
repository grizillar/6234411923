
package lab4_3;

public class TimeInterval {

    public final int interval;

    public TimeInterval(String start,String end){
        int startHour = Integer.parseInt(start.substring(0,2));
        int startMinute = Integer.parseInt(start.substring(2));
        int endHour = Integer.parseInt(end.substring(0,2));
        int endMinute = Integer.parseInt(end.substring(2));
        int timeStart = startHour * 60 + startMinute;
        int timeEnd = endHour * 60 + endMinute;
        this.interval = timeEnd - timeStart;
    }
    public int getHours(){
        return interval / 60;
    }
    public int getMinutes(){
        return interval - ((interval / 60) * 60);
    }
}
