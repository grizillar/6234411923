package interfaceproject;

public interface CanSwim {
    
    void swim(Terrain terrain);
}
