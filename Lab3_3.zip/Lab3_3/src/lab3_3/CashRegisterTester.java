
package lab3_3;

public class CashRegisterTester {
    
    public static void main(String[] args){
        CashRegister self = new CashRegister(7);
        self.recordPurchase(50);
        self.recordPurchase(10);
        self.recordTaxablePurchase(20);
        self.enterPayment(100);
        //System.out.println(self.getTotalTax());
        System.out.println("Your change is "+self.giveChange());
    }
}
