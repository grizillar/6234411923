
package lab3_3;

public class CashRegister {

    private double total;
    private double change;
    private double payment;
    private double tax;
    private final double taxPercent;
    
    public CashRegister(double taxPercent){
        this.taxPercent = taxPercent / 100;
    }
    
    public void recordPurchase(double price){
        total = total + price;
    }
    
    public void recordTaxablePurchase(double price){
        double addValue = taxPercent * price;
        price = price + addValue;
        total = total + price;
        tax = tax + addValue;
    }
    
    public void enterPayment(double payment){
        this.payment = this.payment + payment;
    }
    public double getTotalTax(){
        return tax;
    }
    
    public double giveChange(){
        change = payment - total;
        total = 0;
        payment = 0;
        tax = 0;
        return change; 
    }
}
