package lab10_2;

import java.util.ArrayList;

public class BusTester{
    public static void main(String[] args){
        ArrayList<Object> arr = new ArrayList<Object>();
        arr.add(new Hybrid(45, 1.2, 720, 150, 1));
        arr.add(new CNGBus(50, 1, 200, 2));
        for(Object O : arr){
            if(O instanceof CNGBus) {
                CNGBus B = (CNGBus) O;
                System.out.println(String.format("ID: %d", B.getID()));
                System.out.println(String.format("Emission Tier: %d", B.getEmissionTier()));
                System.out.println(String.format("Accel: %.1f", B.getAccel()));
            }
            if(O instanceof Hybrid) {
                Hybrid B = (Hybrid) O;
                System.out.println(String.format("ID: %d", B.getID()));
                System.out.println(String.format("Emission Tier: %d", B.getEmissionTier()));
                System.out.println(String.format("Accel: %.1f", B.getAccel()));
            }
        }
    }
}