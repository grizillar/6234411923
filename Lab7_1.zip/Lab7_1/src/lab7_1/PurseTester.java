
package lab7_1;

public class PurseTester {

    public static void main(String[] args) {
        
        Purse a = new Purse();
        a.addCoin("Dime");
        a.addCoin("Penny");
        a.addCoin("Quarter");
        
        Purse b = new Purse();
        b.addCoin("Penny");
        b.addCoin("Dime");
        b.addCoin("Quarter");
        
        //a.transfer(b);
        //System.out.println(a.reverse());
        //System.out.println(a.toString());
        System.out.println(a.coins);
        System.out.println(b.coins);
        System.out.println(a.sameContents(b));
        System.out.println(a.sameCoins(b));
    }
    
}
