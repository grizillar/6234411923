
package lab7_1;

import java.util.ArrayList;

public class Purse {
    
    public ArrayList<String> coins = new ArrayList<String>();
    
    public void addCoin(String coinName){
        coins.add(coinName);
    }
    
    @Override
    public String toString(){
        return ""+coins;
    }
    
    public ArrayList<String> reverse(){
        ArrayList<String> reverse = new ArrayList<String>();
        for(int i = coins.size()-1;i >= 0;i--){
            reverse.add(coins.get(i));
        }
        return reverse;
    }
    
    public void transfer(Purse other){
        //OTHER>>THIS
        for(String c:this.coins){
            other.coins.add(c);
        }
        this.coins.clear();
    }
    
    public boolean sameContents(Purse other){
        if(this.coins.size() != other.coins.size()) return false;
        for(int i = 0;i < coins.size();i++){
            if(this.coins.get(i) != other.coins.get(i)) return false; 
        }
        return true;
    }
    
    public boolean sameCoins(Purse other){
        if(this.coins.size() != other.coins.size()) return false;
        return this.coins.containsAll(other.coins) && other.coins.containsAll(this.coins);
    }
}
