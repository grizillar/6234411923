
package lab4_2;

public class DigitExtractor {

    private int count;
    private int integer;

    public DigitExtractor(int anInteger){
        //reverse integer
        integer = (anInteger % 10) * 10000;
        integer = integer + (anInteger % 100) / 10 * 1000;
        integer = integer + (anInteger % 1000) / 100 * 100;
        integer = integer + (anInteger % 10000) / 1000 * 10;
        integer = integer + (anInteger % 100000) / 10000;
    }

    public int nextDigit(){
        String str = Integer.toString(integer);
        str = str.substring(count,count+1);
        int n = Integer.parseInt(str);
        count++;
        return n;
    }
}
