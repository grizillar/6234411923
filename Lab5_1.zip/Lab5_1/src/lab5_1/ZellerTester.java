
package lab5_1;

import java.util.Scanner;

public class ZellerTester{
    
    public static void main(String[] args){
        Scanner in = new Scanner(System.in);
        System.out.print("Enter year (e.g., 2012): ");
        int year = in.nextInt();
        System.out.print("Enter Month (1-12): ");
        int month = in.nextInt();
        System.out.print("Enter day of the month (1-31): ");
        int day = in.nextInt();
        Zeller date = new Zeller(year, month, day);
        System.out.printf("Day of the week is %s",date.getDayOfWeek());


    }
}