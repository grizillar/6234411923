package lab2_3;

import java.util.GregorianCalendar;
import java.util.Calendar;

public class GregorianCal {

    public static void main(String[] args) {
        //GregorianCalendar bday = new GregorianCalendar(2000,Calendar.FEBRUARY, 18);
        //GregorianCalendar today = new GregorianCalendar(2020,Calendar.JANUARY, 20);
        
        GregorianCalendar bday = new GregorianCalendar(1990,Calendar.MARCH, 12);
        GregorianCalendar today = new GregorianCalendar(2019,Calendar.JANUARY, 8);
        
        today.add(Calendar.DAY_OF_MONTH, 100);
        int weekday1 = today.get(Calendar.DAY_OF_WEEK);
        int day1 = today.get(Calendar.DAY_OF_MONTH);
        int month1 = today.get(Calendar.MONTH)+1;
        int year1 = today.get(Calendar.YEAR);
        System.out.println(weekday1 + " " + day1 + " " + month1 + " " + year1);
        
        bday.add(Calendar.DAY_OF_MONTH, 10000);
        int weekday2 = bday.get(Calendar.DAY_OF_WEEK);
        int day2 = bday.get(Calendar.DAY_OF_MONTH);
        int month2 = bday.get(Calendar.MONTH)+1;
        int year2 = bday.get(Calendar.YEAR);
        System.out.println(weekday2 + " " + day2 + " " + month2 + " " + year2);
    }
    
}
