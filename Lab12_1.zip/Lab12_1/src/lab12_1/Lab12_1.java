package lab12_1;

import java.io.*;
import java.util.*;

public class Lab12_1 {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        String s = null;
        String[] words;

        int lineCount = 0;
        int charCount = 0;
        int wordCount = 0;

        try{
            PrintWriter file = new PrintWriter("src\\lab12_1\\text.txt");
            while(true){
                s = in.nextLine();
                if(s.equals("quit")){break;}
                else{file.println(s);}
            }
            file.close();
            in.close();
        }
        catch(FileNotFoundException e){System.out.println(e);}
        catch(NullPointerException e){System.out.println(e);}

        try{
            File file = new File("src\\lab12_1\\text.txt");
            Scanner read = new Scanner(file);
            while(read.hasNext()){
                String str = read.nextLine();         
                lineCount++;
                System.out.println(str);              
                wordCount += str.split("\\s+").length;                
                charCount += str.length();
                
            }
            read.close();
        }
        catch(FileNotFoundException e){System.out.println(e);}

        System.out.println("Total characters : " + charCount);
        System.out.println("Total words : " + wordCount);
        System.out.println("Total lines : " + lineCount);
    }
}
